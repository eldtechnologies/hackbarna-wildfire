from pathlib import Path
from collections import Counter
import hashlib,json,shutil,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parents[2]
RUN=ROOT/'work/paired-benchmark-verified'
OUT=ROOT/'outputs/paired-model-benchmark';OUT.mkdir(parents=True,exist_ok=True)
REPO=ROOT/'work/ola-integration'
rows=json.loads((RUN/'results.json').read_text())['cases'];summ=json.loads((RUN/'summary.json').read_text())
primary=[r for r in rows if r['roi_km']==20 and r['mask']=='novel' and r['horizon']==6]
counts=Counter(r['cluster_id'] for r in primary)
weighted={}
for name in primary[0]['scores']:
 c={k:sum(r['scores'][name][k]/counts[r['cluster_id']] for r in primary) for k in ['tp','fp','fn','tn']}
 tp,fp,fn=c['tp'],c['fp'],c['fn'];c.update(precision=tp/(tp+fp) if tp+fp else None,recall=tp/(tp+fn) if tp+fn else None,f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None)
 weighted[name]=c
(RUN/'equal-cluster.json').write_text(json.dumps({'definition':'Each forecast has weight 1 / number of forecasts for its cluster, then pool weighted counts; not mean per-cluster F1.','horizon':6,'roi_km':20,'mask':'novel','scores':weighted},indent=2)+'\n')
for name in ['protocol.json','eligible.json','results.json','summary.json','verification.json','equal-cluster.json']:
 shutil.copy2(RUN/name,OUT/name)
labels={'model_0.5':'Our model ≥0.50 (primary)','model_0.25':'Our model ≥0.25','model_0.1':'Our model ≥0.10 (secondary)','deepfire_earlier':'DeepFire, earlier hour','deepfire_later':'DeepFire, later hour','dilation_2px':'Fixed 2-pixel dilation','persistence':'Persistence'}
order=['model_0.5','model_0.25','model_0.1','deepfire_earlier','deepfire_later','dilation_2px','persistence']
def table(scores):
 lines=['| Predictor | Found (TP) | Extra alerts (FP) | Missed (FN) | Precision | Recall | F1 |','|---|---:|---:|---:|---:|---:|---:|']
 for k in order:
  v=scores[k];pct=lambda x:'—' if x is None else f'{x:.1%}'
  lines.append(f"| {labels[k]} | {v['tp']:g} | {v['fp']:g} | {v['fn']:g} | {pct(v['precision'])} | {pct(v['recall'])} | {v['f1']:.3f} |")
 return '\n'.join(lines)
s6=next(s for s in summ if s['roi_km']==20 and s['mask']=='novel' and s['horizon']==6)
s3=next(s for s in summ if s['roi_km']==20 and s['mask']=='novel' and s['horizon']==3)
positives=[r for r in primary if r['positive_cells']]
text=f'''# Paired DeepFire / frozen-model benchmark

Measured 20 September 2026. Protocol fixed at 09:23:36 UTC before inference and scoring. This is a retrospective pilot on **38 forecasts from 36 clusters**, with later dates than the frozen model's training data. **All 38 overlap training geography. Only two forecasts contain new positive satellite cells.** Future observability leaves scorable cells in 24 forecasts (23 clusters) at six hours, and 30 forecasts (29 clusters) at three hours. The other matched forecasts contribute no counts; they are not treated as clear negatives.

## Decision

The current model does not demonstrate reliable new-spread prediction. At the primary 0.50 threshold it misses all eight new satellite-positive cell/forecast pairs. At the prespecified secondary 0.10 threshold it catches one with one extra alert. DeepFire catches three with 64–84 extra alerts on this satellite target. A fixed dilation baseline catches two with four extra alerts and has the highest F1 here.

This does not establish a statistically reliable winner. There are only two positive cases. It also does not test physical burned area, road closure time, or evacuation safety. DeepFire predicts a physical simulation footprint; a footprint without a satellite detection is not proof that the ground did not burn.

## Six-hour comparison: new detections only

Common absolute endpoints; actual future observation windows are approximately 5–6 hours because DeepFire starts between our model's whole-hour issue times. Primary radius: 20 km. **7,965 eligible cell/forecast pairs, eight positive pairs**. Negative-only cases stay in the score. Fourteen matched forecasts have no eligible six-hour cells after censoring and contribute zero counts.

{table(s6['scores'])}

“Extra alert” means a predicted positive cell with all scheduled future thermal quality flags clear; it is an FP against this thermal target. Precision is undefined when no alert is made. Do not describe precision as overall accuracy. No thresholds were tuned on these results.

## Three-hour comparison

Approximately 2–3 hours of common future observations; 12,971 eligible pairs and seven positive pairs.

{table(s3['scores'])}

The 10 km sensitivity gives exactly the same TP, FP and FN as 20 km at both horizons. Only true-negative counts change.

## Both cases with new detections

- **La Pobla de Mafumet, Tarragona**: two new positive cells at six hours. Our model at 0.10 finds one with one extra alert; DeepFire finds zero with one extra alert; fixed dilation finds both with four extra alerts.
- **Alfarràs, Lleida**: six new positive cells. Our model at 0.10 finds zero; DeepFire finds three with four to seven extra alerts; fixed dilation finds zero.

![Both positive cases](positive-cases.png)

Grey crosses are model-time detections, red square outlines are later new detections, and blue circles are alerts on eligible new-detection cells. Each mark is a native cell centre; it is not a precise fire perimeter. All panels show the same 20 km region. Cells without eligible observations do not enter the scores.

## Equal-cluster check

For the two clusters with multiple forecasts, each forecast gets weight 1 / number of forecasts in that cluster. Weighted counts are pooled, so each cluster has equal total forecast weight. This is not the mean of per-cluster F1 values.

{table(weighted)}

These are weighted cell counts, not numbers of independent fires. Clusters with unobservable forecasts have correspondingly incomplete evidence under these fixed weights. No cell-level confidence interval is reported: it would overstate the amount of independent evidence.

## Input and target audit

1. Select all completed, exact-cluster-linked runs in the previously saved 500-run archive for which the model issue plus six hours fits inside the local raw archive. This yields 38 of 45 such runs; seven exceed archive coverage. No outcome-based selection or preparation failures.
2. Use the archived simulation origin as the fixed patch centre. Our issue time is the whole hour at or before the archived DeepFire creation time. Our inputs are 2.73–59.39 minutes older. Location information is therefore supplied from the DeepFire issue, while dynamic features are cut off at the earlier model hour. This is not a simultaneous operational replay.
3. Reconstruct the frozen 64×64 native-grid features using only available history through that hour. Weather is the same previous-day forecast product used by training. Source product availability is checked. Static terrain is unchanged. One original held-out input and persistence field reproduce bit for bit.
4. Freeze all 38 model predictions before reading future label values. Model probabilities come from the original checkpoint and calibration; no retraining or model promotion.
5. Start the shared label window at the first ten-minute scan at/after DeepFire creation. End at our issue +3h or +6h. For new-detection scoring, exclude any cell with a detected fire in the preceding three hours through that start, and any positive frozen input-history bin. Require observable model history and exclude the frozen pre-training persistent-heat prior.
6. A future cell is positive if any scheduled quality flag is 1 or 2. It is negative only when all scheduled flags are 0. Cloud, missing and otherwise unknown cells are censored rather than labelled negative.
7. Transform saved DeepFire hourly polygons into the exact MTG native grid. Rasterize with the fixed `rasterio.features.rasterize(all_touched=True)` rule. Union polygons through both the floor and ceiling forecast hour around the common absolute endpoint. Report both time brackets.
The independent geometry check found one narrow boundary intersection (44.25 m²) that the rasterizer omits. It lies in a previously positive cell: no new-detection score changes. An exact-intersection rasterizer would add one TP and remove one FN in the secondary all-cell, three-hour DeepFire-earlier result at both radii. We retain the preregistered rasterizer and record this implementation limit; “any intersection” in the frozen protocol names the intended all_touched rule, not an exact computational-geometry guarantee.

8. DeepFire documentation defines the result as hourly spread polygons and clusters as candidate fires ([fire-spread API](https://docs.deepfire.co/api/fire-spread), [clusters API](https://docs.deepfire.co/api/clusters)). The archive does not expose all internal simulation inputs; this audit cannot prove the provider’s full input causality.
9. Score the same eligible cells for every predictor. Fixed dilation expands the model-time persistence state by two native grid pixels. Native pixels have varying ground footprints; these outputs do not resolve individual roads or buildings.

The original model's strongest held-out evaluation and this comparison have different cohorts and targets; their AP values must not be compared to these F1 values. All cases here are later in time, but familiar in geography. Some satellite hotspots may be non-wildfire heat sources. These are additional reasons to avoid claiming proven wildfire or evacuation performance.

## Reproduction and frozen handoff

Two independent executions produce **exactly equal aggregate scores and all 114 array files** (38 inputs/predictions + 76 horizon labels). Input parity is exact for the original held-out sample. A separate scikit-learn confusion-matrix rescore matches all 2,128 predictor/case rows, including the empty masks. See `verification.json`.

`frozen-benchmark.zip` holds fixed inputs, predictions, labels, weather, simulation records, protocol, case selection and source snapshots. `SHA256SUMS.json` records file identities. Raw MTG archives, original training data and original checkpoint are local prerequisites for a full reconstruction; their hashes and locations are recorded in the protocol/manifest. The zip is sufficient to rescore cached predictions and reuse the fixed evaluation target. It contains no API credentials.

For a full reconstruction, use the scientific Python environment with the original trainer and data-work root, and make a fresh directory containing `protocol.json`, `eligible.json` and `weather/` from the bundle:

```sh
python tools/validation/paired_deepfire.py \\\n  --data-work-root /path/to/original/work \\\n  --run-directory /path/to/fresh/run \\\n  --archive-directory /path/to/bundle/simulations
```

The runner refuses an existing frames directory. It pins the original checkpoint, trainer and manifest identities. The paths inside the original manifest must still resolve. This is a frozen run-001 benchmark, not a generic checkpoint loader.

When the next checkpoint is ready, use these exact case IDs, labels, masks, horizons and thresholds. First check whether the new training process has seen these dates or labels. If it has, any score gain here is a development-set result; it cannot establish held-out improvement. A changed architecture or feature schema needs its own past-only input adapter and parity checks.
'''
(OUT/'Measured comparison.md').write_text(text)
# Scientific comparison figure: show all cases with positives, not selected successes.
fig,axes=plt.subplots(2,4,figsize=(16,8),sharex='row',sharey='row',layout='constrained')
cols=[('Observed new detections',None),('Our model ≥0.10','model'),('DeepFire earlier hour','deepfire_earlier'),('Fixed 2-pixel dilation','dilation')]
from scipy.ndimage import distance_transform_edt
for ri,r in enumerate(positives):
 sid=r['simulation_id']
 with np.load(RUN/'frames'/f'{sid}.npz') as f,np.load(RUN/'frames'/f'{sid}-h6-labels.npz') as l:
  lon,lat=f['lon'],f['lat'];loc=next(v for v in json.loads((RUN/'eligible.json').read_text()) if v['id']==sid);east=(lon-loc['lon'])*111.2*np.cos(np.radians(loc['lat']));north=(lat-loc['lat'])*111.2
  use=l['valid'].astype(bool)&l['novel'].astype(bool)&l['roi'].astype(bool);truth=use&l['y'].astype(bool);past=f['p']>0
  for ci,(title,key) in enumerate(cols):
   ax=axes[ri,ci];ax.scatter(east[use],north[use],s=5,color='#dfdfdf');ax.scatter(east[past],north[past],s=40,marker='x',color='#777777')
   if key:
    pred=f['pred'][2]>=.1 if key=='model' else (distance_transform_edt(~past)<=2 if key=='dilation' and past.any() else np.zeros_like(past) if key=='dilation' else l[key])
    alert=use&pred;ax.scatter(east[alert],north[alert],s=70,facecolors='none',edgecolors='#1878c4',linewidths=1.8)
   ax.scatter(east[truth],north[truth],s=135,marker='s',facecolors='none',edgecolors='#cb3636',linewidths=1.7)
   ax.plot(0,0,'k+',ms=7);ax.set(xlim=(-21,21),ylim=(-21,21),aspect='equal');ax.grid(alpha=.2);ax.set_xlabel('East from saved origin (km)')
   if ri==0:ax.set_title(title,fontsize=12)
   if ci==0:ax.set_ylabel(r['name'].split(',')[0]+'\nNorth (km)')
fig.suptitle('New MTG detections: both positive cases in the 38-forecast pilot\nCommon ~5–6h window • grey = existing detections • red squares = new detections • blue circles = alerts',fontsize=14)
fig.savefig(OUT/'positive-cases.png',dpi=170);plt.close(fig)
# Bundle exact scoring material plus source snapshots; no credentials.
bundle=ROOT/'work/paired-benchmark-bundle';bundle.mkdir(exist_ok=True)
for name in ['protocol.json','eligible.json','results.json','summary.json','verification.json','input-parity.json','preparation.json','equal-cluster.json']:
 shutil.copy2(RUN/name,bundle/name)
for name in ['frames','weather']:
 shutil.copytree(RUN/name,bundle/name,dirs_exist_ok=True)
(bundle/'simulations').mkdir(exist_ok=True)
for row in primary:
 sid=row['simulation_id'];shutil.copy2(ROOT/'work/deepfire-check/archive-audit'/f'{sid}-simulation.json',bundle/'simulations'/f'{sid}-simulation.json')
(bundle/'source').mkdir(exist_ok=True)
for name in ['paired_deepfire.py']:
 shutil.copy2(REPO/'tools/validation'/name,bundle/'source'/name)
for name in ['inputs.py','quality.py','weather.py','common.py','terrain.py','train.py']:
 source=(REPO/'tools/next_run'/name if name=='inputs.py' else Path('/Users/ola/Documents/Codex/2026-09-19/file-users-ola-downloads-hackbarna-20/work/next-run-pipeline/tools/next_run')/name)
 shutil.copy2(source,bundle/'source'/name)
for name in ['prepare.py','preflight.py','make_report.py']:
 shutil.copy2(ROOT/'work/paired-benchmark'/name,bundle/'source'/name)
shutil.copy2(OUT/'Measured comparison.md',bundle/'README.md')
shutil.copy2(OUT/'positive-cases.png',bundle/'positive-cases.png')
hashes={str(p.relative_to(bundle)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(bundle.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.json'}
(bundle/'SHA256SUMS.json').write_text(json.dumps(hashes,indent=2)+'\n')
shutil.copy2(bundle/'SHA256SUMS.json',OUT/'SHA256SUMS.json')
with zipfile.ZipFile(OUT/'frozen-benchmark.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(bundle.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(bundle))
# Small, reviewable results and protocol in repository; bulk tensors remain in deliverable.
doc=REPO/'docs/validation/deepfire-paired';doc.mkdir(exist_ok=True)
for name in ['Measured comparison.md','protocol.json','eligible.json','summary.json','equal-cluster.json','verification.json','positive-cases.png']:
 shutil.copy2(OUT/name,doc/name)
print(json.dumps({'frozen_files':len(hashes),'bundle_mb':round((OUT/'frozen-benchmark.zip').stat().st_size/1e6,2),'positive_cases':[r['name'] for r in positives],'equal_cluster':weighted},indent=2))
