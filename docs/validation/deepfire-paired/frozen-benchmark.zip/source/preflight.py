from pathlib import Path
import json,sys,numpy as np,pandas as pd
BASE=Path('/Users/ola/Documents/Codex/2026-09-19/file-users-ola-downloads-hackbarna-20/work')
sys.path.insert(0,str(BASE/'next-run-pipeline'))
from tools.next_run.quality import GEOS,Quality
from tools.next_run.weather import location
ROOT=Path(__file__).resolve().parents[2];A=ROOT/'work/deepfire-check/archive-audit';m=json.loads((BASE/'next-run-data/full-v1/manifest.json').read_text());cfg=m['config'];weather=json.loads((Path(cfg['weather'])/'index.json').read_text());events=[e for e in m['events'] if e['samples']];q=Quality(cfg['archive']);rows=[]
for s in json.loads((A/'cohort.json').read_text()):
 d=json.loads((A/(s['id']+'-simulation.json')).read_text())['data'];x,y=GEOS(d['longitude'],d['latitude']);r,c=int(np.rint(5567.5-y/1000)),int(np.rint(x/1000+5567.5));group=f'native256-{r//256}-{c//256}';overlap=[e for e in events if abs(e['seed_row']-r)<64 and abs(e['seed_col']-c)<64];t=pd.Timestamp(d['createdAt']).floor('h');key=f'{location(d["longitude"],d["latitude"])[0]},{location(d["longitude"],d["latitude"])[1]}'
 # Whole source availability only, no future label values are read.
 scans=pd.date_range(t-pd.Timedelta(hours=3),t+pd.Timedelta(hours=6),freq='10min',inclusive='left');present=sum(v.strftime('%Y%m%d%H%M') in q.files for v in scans)
 rows.append({'id':s['id'],'cluster_id':s['clusterId'],'name':d.get('locationName'),'lat':d['latitude'],'lon':d['longitude'],'model_issue':t.isoformat(),'deepfire_issue':d['createdAt'],'duration':d['durationHours'],'row':r,'col':c,'spatial_group':group,'group_roles':sorted({e['role'] for e in events if e['spatial_group']==group}),'overlap_roles':sorted({e['role'] for e in overlap}),'weather_cached':key in weather['locations'],'weather_key':key,'scan_files_present':present,'scan_files_needed':len(scans)})
(ROOT/'work/paired-benchmark/preflight.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:print(json.dumps(r))
